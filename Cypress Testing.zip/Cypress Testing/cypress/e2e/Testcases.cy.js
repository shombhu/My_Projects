describe('My Testing',()=>{

    it('Read data from fixture file',()=>{
        cy.visit('https://www.saucedemo.com/')
        cy.fixture('LoginData').then ((data)=>{
            cy.get("#user-name").type(data.username);
            cy.get("#password").type(data.password);
            cy.get("input[id='login-button']").click();
            
            cy.get(".title").should('have.text',data.expected);
        })

        
    })
})