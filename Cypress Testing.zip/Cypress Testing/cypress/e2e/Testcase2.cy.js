describe('template spec', () => {

  before(()=>{
    cy.log("In Before Hook ----------------")
  })
  after(()=>{
    cy.log("In After Hook ----------------")
  })
  beforeEach(()=>{
    cy.log("In Before Each Hook ----------------")
  })
  afterEach(()=>{
    cy.log("In After Each Hook ----------------")
  })

  it('Test1', () => {
    //cy.visit('https://example.cypress.io')
    cy.log("in Test1")
  })
  it('Test2', () => {
    //cy.visit('https://example.cypress.io')
    cy.log("in Test2")
  })
})