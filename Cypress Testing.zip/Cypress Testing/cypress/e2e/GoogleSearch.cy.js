describe('template spec', () => {
  it('passes', () => {
    cy.visit('www.google.com')
    cy.xpath("//*[@id='APjFqb']").type("cypress")
    cy.xpath("//*[@class='QCzoEc z1asCe MZy1Rb']").click()
    cy.go('forward');
    cy.screenshot("w")
  })


})